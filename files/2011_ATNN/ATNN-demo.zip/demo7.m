clc
clear all

scaled=1;%determines wheather the comparator is scaled or not

sh=32;%sharpness of fuzzy comparator

r=pi;%for plot (radius of samples)
c=0;%for plot (center of samples)
num=5000;%for plot (number of samples)
samplesX=(rand(1,num)-.5)*2*r+c;%random samples
samplesY=(rand(1,num)-.5)*2*r+c;%random samples
target_values=-sinc (1./sqrt(samplesX.^2+samplesY.^2)).*sqrt(samplesX.^2+samplesY.^2).^.5;%target values
samples=[samplesX;samplesY];

Treshold=.0001;%threshold of the hole ATNN
df =5;%number of hidden units of the base netwrok

trc=.5; %parameter of fuzzy selection of tiles
%trc: spreading constant 
%.5: no spreading 
%0 : max spreading
%1 : back spreading


X=initTILE(samples,df,target_values); %initializing the ATNN
[X] = trainTILE(X,samples,target_values,Treshold,trc,sh,scaled) %training the ATNN

%calculation of the mse (mean square error)
mse=mean((retriv(samples,X,sh,scaled)-target_values).^2)

%drawing the result

clc
base1=[-1.2*pi:.1:1.2*pi];
base2=[-1.2*pi:.1:1.2*pi];


clear in;
for i = 1:size(base1,2)
    for j = 1:size(base2,2)
        in(:,i,j)=[base1(i);base2(j)];
    end
end
out=retriv(reshape(in,2,[]),X,sh,scaled);%computing output
t=reshape(out,size(base1,2),size(base2,2),1);
x=reshape(in(1,:,:),size(base1,2),size(base2,2));
y=reshape(in(2,:,:),size(base1,2),size(base2,2));


surf(x,y,t)
hold on
A=reshape(X.upperB,2,[]);
B=reshape(X.downB,2,[]);
X1=A(1,:);
Y1=A(2,:);
X2=B(1,:);
Y2=B(2,:);

plot3([X1;X2;X2;X1;X1],[Y1;Y1;Y2;Y2;Y1],ones(5,size(X1,1)),'Color', [0 .5 0])
