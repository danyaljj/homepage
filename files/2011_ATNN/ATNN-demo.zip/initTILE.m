function X=initTILE(samples,df,target_values)
%initialization

%bounds are vectors with as many elements as samples' elements

%maximum values are chosen for the upper bound
%mainimum values are chosen for the lower bound
X.upperB=ones(size(samples,1),1) .* max(samples,[],2);
X.downB =ones(size(samples,1),1) .* min(samples,[],2);


X.df=df;%hidden units of the base network
X.target_values=target_values;%sampling target value (for creating base network later)
X.samples=samples;%sampling sample (for creating base network later)

    net = newff(samples,target_values,df);% making the tiles
    X.IW(:,:,1)=net.IW;%initializing the size of IW b and LW params of X
    X.b(:,:,1)=net.b;
    X.LW(:,:,1)=net.LW;