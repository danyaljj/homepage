function [UBonds DBonds] =splitB(A,B,n)
%spliting tile with upper bound A and lower bound B
%along the nth dimension

%doubling the bonds to be two tiles
UBonds=repmat(A,[1,1,2]);
DBonds=repmat(B,[1,1,2]);

%mn: mean of upper bound and lower bands : tile center
mn=(A(n,1)+B(n,1))/2;

ol=(A(n,1)-B(n,1))*.0;
%the ol determines the overlapping

UBonds(n,1,2)=mn+ol;
DBonds(n,1,1)=mn-ol;