clc
clear all

scaled=1;%determines wheather the comparator is scaled or not

sh=32;%sharpness of fuzzy comparator

r=pi;%for plot (radius of samples)
c=0;%for plot (center of samples)
num=1000;%for plot (number of samples)
samples=(rand(1,num)-.5)*2*r+c;%random samples

u=c+r;%for plot
d=c-r;%for plot
target_values=cos(samples);%target values

Treshold=.000001;%threshold of the hole ATNN
df =[];%number of hidden units of the base netwrok

trc=.5; %parameter of fuzzy selection of tiles
%trc: spreading constant 
%.5: no spreading 
%0 : max spreading
%1 : back spreading


X=initTILE(samples,df,target_values); %initializing the ATNN
[X] = trainTILE(X,samples,target_values,Treshold,trc,sh,scaled) %training the ATNN

%calculation of the mse (mean square error)
mse=mean((retriv(samples,X,sh,scaled)-target_values).^2)

%drawing the result

in=[-2*pi:.001:2*pi];
out=retriv(in,X,sh,scaled);%computing output
plot(in,out,'LineWidth',2)% drawing output
hold on

%plotting target in a bigger area
plot(in,cos(in),'--r','LineWidth',2)



xlabel (['mse = ' num2str(mse) ' & df = ' num2str(df) ...
    ' & Treshold = ' num2str(Treshold) ' on ' num2str(num) ...
    ' random samples of [' ...
    num2str(d) ',' num2str(u) ']'])

%parameters of drawing tiles under the plot
u1u=min(out)-.1;
u2u=min(out)-.2;

%parameters of drawing tiles over the plot
%u1u=max(out)+.1;
%u2u=max(out)+.2;


%drawing tiles
A=ones([2 size(reshape(X.upperB,1,[]),2)])*u1u;
B=ones([2 size(reshape(X.upperB,1,[]),2)])*u2u;
C=ones([1 size(reshape(X.upperB,1,[]),2)])*u1u;
plot( ...
[reshape(X.upperB,1,[]);
 reshape(X.downB,1,[]);
 reshape(X.downB,1,[]) ;
 reshape(X.upperB,1,[]);
 reshape(X.upperB,1,[])], ...
 [A;B;C],'Color', [0 .5 0])
clear A B C

hold off
