function [X] = trainTILE(X,samples,target_values,Treshold,trc,sharpness,sc)
%X       : the ATNN
%samples : n x m : m samples with n element
%target  : t x m : m samples with t element
%Treshold: threshold parameter
%trc     : threshold of fuzzy selection


%trc: spreading constant 
%.5: no spreading 
%0 : max spreading
%1 : back spreading

%number of tiles : q

%upperB : n x q
%downB  : n x q


df=X.df;


    net = newff(samples,target_values,df);% making the tiles
    net.trainFcn='trainlm';
    net.divideFcn='';
    net.trainParam.goal=Treshold;
    net=init(net);% initializing the tiles
    net.trainParam.showWindow=false;
    net.trainParam.showCommandLine=true;
    net.trainParam.epochs=500;
    net.trainParam.min_grad=Treshold;

i=1;
while(i<=size(X.upperB,3)) % for all q tiles

    

%distributting data into tiles and training the networks
UB=repmat(X.upperB(:,:,i),  [1 , size(samples,2) , 1]  ); %UB: n x m x 1
DB=repmat(X.downB (:,:,i),  [1 , size(samples,2) , 1]  ); %DB: n x m x 1

DATA=samples;%DATA: n x m x 1


%fuzzy selection
places=min(min(compare(DB,DATA,UB-DB,sharpness,sc), compare(DATA,UB,UB-DB,sharpness,sc)),[],1);%places 1 x m x 1
%trc: the treshold of belonging for spreading the data

places=places>trc;
%determins if sample m is in tile i (current value of i)
    
    
    SMPLIST=[];% samples for this tile
    TRGLIST=[];% targets for this tile
    for j = 1:size(places,2) % for all m samples
        if (places(1,j)) %if the sample is in the tile
            SMPLIST=[SMPLIST samples(:,j)]; %add it to list
            TRGLIST=[TRGLIST target_values(:,j)];% add its target to list
        end
    end
    
net=init(net);%initialize network

if (size(SMPLIST,2)>0) %if there is any sample in this tile
    [net pr]=train(net,SMPLIST,TRGLIST);%train the tile

    %spliting the tile if necessary using messure of pr.perf(end)
    %(performance of training)
    if (pr.perf(end)>Treshold)
        %splitting
        %------------------------------------------
        bondis=X.upperB(:,:,i)-X.downB(:,:,i);
        [a n] = max(bondis,[],1);
        [UBonds DBonds] =splitB(X.upperB(:,1,i),X.downB(:,1,i),n);
        X.upperB(:,:,i)=UBonds(:,:,1);
        X.downB(:,:,i)=DBonds(:,:,1);
        X.upperB(:,1,end+1)=UBonds(:,:,2);
        X.downB(:,1,end+1)=DBonds(:,:,2);

        X.IW(:,:,end+1)=net.IW;
        X.b(:,:,end+1)=net.b;
        X.LW(:,:,end+1)=net.LW;        
        %------------------------------------------
    else
        %extracting data from net and saving to X
        X.IW(:,:,i)=net.IW;
        X.b(:,:,i)=net.b;
        X.LW(:,:,i)=net.LW;
        i=i+1;% going to next tile
    end
else
    i=i+1;%if there is no samples in this tile skip it
end

end


