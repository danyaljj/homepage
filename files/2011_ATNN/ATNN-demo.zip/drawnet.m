%training an NN and plotting it on the same figure
clc

df=10;
net = newff(samples,target_values,df);
net.divideFcn='';
net.trainParam.goal=.00001;
net=init(net);
net=train(net,samples,target_values);
clc

%1d
hold on
out=sim(net,in);
mse2=mean((sim(net,samples)-target_values).^2)
plot(in,out,'g','LineWidth',2)
hold off
%surf(x,y,t)