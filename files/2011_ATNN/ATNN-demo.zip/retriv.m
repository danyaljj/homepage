function r = retriv(s,X,sh,sc)
% s : n x m : m samples with n elements
% q : tiles number
%output: t x m : m targets with t elements
df=X.df;
clc

net = newff(X.samples,X.target_values,df);
r=[];

%splitting data into tiles and training the networks
UB=repmat(X.upperB,[1,size(s,2),1]); %    UB : n x m x q
DB=repmat(X.downB,[1,size(s,2),1]);  %    DB : n x m x q
DATA=repmat(s,[1,1,size(X.upperB,3)]);% DATA : n x m x q

places=min( min(compare(DB,DATA,UB-DB,sh,sc) , compare(DATA,UB,UB-DB,sh,sc)) ,[],1);
%determins weather a sample is in a tile (fuzzy) : 1 x m x q

%count=zeros(1,size(places,2));
out=zeros(1,size(places,2)); %outputs t x m
for i=1:size(places,3)
    net.IW=X.IW(:,:,i);%setting tile
    net.b=X.b(:,:,i);
    net.LW=X.LW(:,:,i);
    out=out+sim(net,s).*places(1,:,i); %suming the results
end
count=sum(places,3); %summing the weights
r=out./count; % results : weighted out / sum of weights (mean)
