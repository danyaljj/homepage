function c= compare(A,B,SCALE,sharpness,sc)
%parameters:
%A        : first number
%B        : second number
%SCALE    : scale of comparison
%SHARPNESS: sharpness of fuzzy comparator
%sc       : wheather it is scaled or not
if sc
c=1./(1+exp(-sharpness*(B-A)./SCALE));
else
c=1./(1+exp(-sharpness*(B-A)));
end