// constants.h
// Evan Lord
// Created: July 10, 2007
// Last Modified: July 10, 2007

#define INCREMENT 10000    // increment for dynamic array creation
#define CONSTRAINT_COLS 3  // number of columns in constraint file
#define HEAD 0             // index for head pointer in 2D-array of pointers
#define TAIL 1             // index for tail pointer in 2D-array of pointers
#define MAX_LABEL_SIZE 50
#define LABELS_INCREMENT 10
#define ASCII_ZERO 48
#define TERM_CRITERION 1
#define REPEAT 1
