function [] = experiment(X, Y, experimentName, rate, p)

disp('testing TVClust ... '); 

iter = 1;
name1 = [experimentName '_iter=' num2str(iter)];
name1 = strrep(name1, '.', '_');
dataAll = {};
assignmentAll = {};
titles = {};
calculationTime = {};

% make E matrix
E = zeros(size(Y, 1), size(Y, 1));
Checked = zeros(size(Y, 1), size(Y, 1));
randSize = rate * size(Y, 1) * size(Y, 1);
iterAll = 1;
while(1)
    i1 = randi(size(Y, 1));
    i2 = randi(size(Y, 1));
    if i1 == i2
        continue;
    end
    if Checked(i1, i2) == 0
        correct = (rand() < p);
        Checked(i1, i2) = 1;
        if Y(i1) == Y(i2)
            if correct == 1
                E(i1, i2) = 1;
                E(i2, i1) = 1;
            else
                E(i1, i2) = -1;
                E(i2, i1) = -1;
            end
        else
            if correct == 1
                E(i1, i2) = -1;
                E(i2, i1) = -1;
            else
                E(i1, i2) = 1;
                E(i2, i1) = 1;
            end
        end
        iterAll = iterAll + 1;
    end
    if( iterAll > randSize)
        break;
    end
end

%% true labels
name = 'True labels';
if ~containsMethod(name, titles)
    ind = length(dataAll);
    dataAll{ind+1} = X;
    assignmentAll{ind+1} = Y;
    titles{ind+1} = name;
end

%% TVClust variational :
name = 'TVClust(variational)';
if ~containsMethod(name, titles)
    SM = -1 * ones(size(E));
    SM(E == 1) = 1;
    SM(E == -1) = 0;

    tic;
    [assignment] = TVClust_variational(Checked, SM, X);
    ind = length(dataAll);
    calculationTime{ind+1} = toc;
    dataAll{ind+1} = X;
    assignmentAll{ind+1} = assignment;
    titles{ind+1} = name;
end

try 
    result = calculateResults(dataAll, assignmentAll, titles, Y);
catch 
end

title = ['Experiment= ' experimentName ' | sample size= ' num2str(size(X,1)) ' | sampling rate= ' num2str(rate) ' | constraint confidence= ' num2str(p) ];
h = plotExperiments(dataAll, assignmentAll, titles, 1, 2, title);

saveas(h, name1, 'png')

