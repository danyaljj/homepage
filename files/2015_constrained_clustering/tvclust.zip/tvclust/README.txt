This code contains the Two-View Clustering (TVClust) proposed in [1].
To run this you essentially need to have R installed on your machine. 
To see a sample run of the algorithm run 'test_run.m'
In case you use this code, please code [1]. 
The code is tested on a Windows 8, MATLAB 2014a, R 2.7.1 (2008)

Core designer: Jeffrey Yufei Liu 
MATLAB wrapper: Daniel Khashabi. 

[1] Y. Liu. �Statistical modeling of heterogeneous data.� PhD Dissertation, University of Illinois at Urbana-Champaign, 2013. 