rate = 0.03; % the rate of sampling constraints 
p = 1; 
[X,Y] = gaussians(200);
size1 = size(X,1);
order = randperm(size1);
X = X(order,:);
Y = Y(order,:);
k = 2;    
experiment(X,Y, 'Gaussian-Mixtures', rate, p);

data = clusterincluster();
X = data(:,1:2);
Y = data(:,3);
size1 = size(X,1);
order = randperm(size1);
X = X(order,:);
Y = Y(order,:);
k = 2;
experiment(X,Y, 'Cluster-In-Cluster', rate, p);
    